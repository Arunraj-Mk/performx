import footerImage from "@/assets/images/Footer.png";
import performImage from "@/assets/images/perform.png";
import { Facebook, Linkedin, Twitter, Youtube } from "lucide-react";


const Footer = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      const offset = 100
      const elementPosition = element.getBoundingClientRect().top
      const offsetPosition = elementPosition + window.pageYOffset - offset

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      })
    }
  }
  return (
    <section className="relative bg-[#154033] min-h-screen flex flex-col px-4 sm:px-8 lg:px-20 py-8 sm:py-12 lg:py-16 text-white font-sans overflow-hidden">
      <div className="flex flex-col lg:flex-row justify-between items-start gap-8 sm:gap-12 lg:gap-0 max-w-7xl mx-auto w-full">
        <button
          className="flex justify-center items-center border-[1.5px] border-[#8AF135] bg-[#8AF135] text-black font-semibold text-sm sm:text-base hover:opacity-90 transition px-4 sm:px-5 lg:px-[21.5px] py-2.5 sm:py-3 lg:py-[13.45px] lg:pb-[11.65px]"
        >
          <span
            className="cursor-pointer"
            onClick={() => {
              window.open(
                'https://calendly.com/ceo-perform100x/30min',
                '_blank',
                'noopener,noreferrer'
              )
            }}
          >
            Book a demo
          </span>
        </button>


        <div className="w-full lg:w-1/2 relative flex justify-center lg:justify-end mt-4 lg:mt-0">
          <img
            src={footerImage}
            alt="Footer illustration"
            className="max-w-[280px] sm:max-w-[340px] lg:max-w-[424px] w-full h-auto object-contain"
          />
        </div>
      </div>

      <div className="max-w-7xl mx-auto w-full mt-8 sm:mt-12 lg:mt-16 border-b-[2px] border-white/80 pb-4 sm:pb-6 flex flex-col lg:flex-row justify-center items-center text-white text-sm font-normal tracking-wide">
        <nav
          className="flex flex-wrap justify-center gap-4 sm:gap-6 lg:gap-8 lg:gap-10 text-white text-sm sm:text-base lg:text-[20px] font-normal not-italic leading-normal"
          style={{ fontFamily: "Epilogue, sans-serif", letterSpacing: "0.4px" }}
        >
          <button 
            onClick={() => scrollToSection('hero')} 
            className="hover:text-[#82D83A] transition whitespace-nowrap bg-transparent border-none cursor-pointer text-inherit"
          >
            Home
          </button>
          <button 
            onClick={() => scrollToSection('about')} 
            className="hover:text-[#82D83A] transition whitespace-nowrap bg-transparent border-none cursor-pointer text-inherit"
          >
            About
          </button>
          <button 
            onClick={() => scrollToSection('why-us')} 
            className="hover:text-[#82D83A] transition whitespace-nowrap bg-transparent border-none cursor-pointer text-inherit"
          >
            Why us
          </button>
          <button 
            onClick={() => scrollToSection('services')} 
            className="hover:text-[#82D83A] transition whitespace-nowrap bg-transparent border-none cursor-pointer text-inherit"
          >
            Services
          </button>
          <button 
            onClick={() => scrollToSection('contact')} 
            className="hover:text-[#82D83A] transition whitespace-nowrap bg-transparent border-none cursor-pointer text-inherit"
          >
            Contact
          </button>
        </nav>
      </div>

      <div className="max-w-7xl mx-auto w-full flex justify-center lg:justify-end mt-4 sm:mt-6">
        <div className="flex bg-white text-[#154033] drop-shadow-[0_0_1px_rgba(0,0,0,0.15)] rounded-sm px-3 sm:px-4 py-1 gap-4 sm:gap-6 items-center cursor-pointer shrink-0">
          <a aria-label="YouTube" href="#" className="hover:text-[#82D83A]">
            <Youtube size={16} className="sm:w-[18px] sm:h-[18px]" />
          </a>
          <a aria-label="Twitter" href="#" className="hover:text-[#82D83A]">
            <Twitter size={16} className="sm:w-[18px] sm:h-[18px]" />
          </a>
          <a aria-label="LinkedIn" href="#" className="hover:text-[#82D83A]">
            <Linkedin size={16} className="sm:w-[18px] sm:h-[18px]" />
          </a>
          <a aria-label="Facebook" href="#" className="hover:text-[#82D83A]">
            <Facebook size={16} className="sm:w-[18px] sm:h-[18px]" />
          </a>
        </div>
      </div>

      <div className="max-w-7xl mx-auto w-full mt-4 sm:mt-6 text-xs sm:text-sm lg:text-[14px] font-bold tracking-wide text-center lg:text-left">
        © 2025 PERFORM100X. ALL RIGHTS RESERVED.
      </div>

      <img
        src={performImage}
        alt="Perform100x"
        className="absolute bottom-0 left-1/2 -translate-x-1/2 pointer-events-none select-none opacity-30 sm:opacity-40 w-full max-w-[800px] sm:max-w-[1200px] lg:max-w-[1460px] h-auto object-contain"
        aria-hidden="true"
      />
    </section>
  );
};

export default Footer;
