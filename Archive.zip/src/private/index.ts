// Private components that require authentication
// Example: export { default as PrivateHeader } from './PrivateHeader'
